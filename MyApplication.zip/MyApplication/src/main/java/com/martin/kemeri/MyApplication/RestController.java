package com.martin.kemeri.MyApplication;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class RestController {
    @GetMapping("/{id}")
    public Flight getData(@PathVariable int id) {
        Flight flight = new Flight();
        flight.setId(id);
        flight.setOrigin("Germany");
        flight.setDestination("Croatia");
        return flight;
    }

    @PostMapping("/flight")
    public void postData(@RequestBody Flight flight) {

        System.out.println("Adatok: " + flight);
    }
}
